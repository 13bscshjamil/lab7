<?php
    $str = file_get_contents('dictionary.json');
    $json = json_decode($str, true);
    $keys = array_keys($json);
?>

<html>
    <head>
    <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <h1> Dictionary</h1>
        <form method="post" action="">
            <input type="text" name="get_word">
            <input type="submit" value="Search">
        </form>
        <br><br>
        <div>
            <table>
                <?php
                    if(isset($_POST["get_word"]) && $_POST["get_word"] != ""){
                        echo "&nbsp Word &nbsp &nbsp  &nbsp&nbsp &nbsp Meaning</th></tr>";
                        foreach($keys as $key){
                            if(strpos($key, strtoupper($_POST["get_word"]))){
                                echo "<tr><td>" . $key . "</td><td>" . $json[$key] . "</td></tr>";
                            }
                        }
                    }
                ?>
            </table>         
        </div>
    </body>
</html>